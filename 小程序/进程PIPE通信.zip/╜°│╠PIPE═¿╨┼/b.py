#!/usr/bin/env python
#-*- coding:utf-8 -*-
import sys, time


sys.stdout.write('child:START\n')
sys.stdout.flush()
while(True):
	s = raw_input()
	if s == 'exit':break
	sys.stdout.write('child:get %s\n' %s)
	sys.stdout.flush()
	time.sleep(2)
sys.stdout.write('child:END\n')



