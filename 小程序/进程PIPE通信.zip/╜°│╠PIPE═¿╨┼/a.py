#!/usr/bin/env python
#-*- coding:utf-8 -*-
import subprocess, time, sys

sys.stdout.write('parent:START\nparent:open child...\n')
child = subprocess.Popen(['python','b.py'], shell=True,\
	stdin=subprocess.PIPE, stdout=subprocess.PIPE)
sys.stdout.write(child.stdout.readline())
print dir(child.stdout)
print child.stdout.newlines
while(True):
	command = raw_input('parent:input sth:');command +='\n'
	sys.stdout.write('parent:send: %s' % command)
	if child.poll() ==None:child.stdin.write(command);child.stdin.flush()
	sys.stdout.write('parent:finish send\n')
	sys.stdout.write(child.stdout.readline())
	if command == 'exit\n':
		sys.stdout.write(child.stdout.readline())
		child.stdin.close();child.stdout.close();break

sys.stdout.write('parent:END\n')


