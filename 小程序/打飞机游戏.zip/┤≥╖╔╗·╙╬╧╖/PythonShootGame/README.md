PythonShootGame
===============

A simple shoot game by python


This project only include two simple .py files: 

  mainGame.py：the initialization and main loop of the game
  
  gameRole.py: class of the game role
  
  
To run this game, first install python 2.7, then install the corresponding version of pygame.
After that, double click the mainGame.py, you can play it.
